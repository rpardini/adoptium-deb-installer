export JAVA_HOME=/usr/lib/jvm/adoptopenjdk-11-jdk-openj9
