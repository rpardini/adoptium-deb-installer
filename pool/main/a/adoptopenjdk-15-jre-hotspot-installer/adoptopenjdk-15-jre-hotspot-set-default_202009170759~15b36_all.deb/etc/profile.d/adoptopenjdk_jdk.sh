export JAVA_HOME=/usr/lib/jvm/adoptopenjdk-15-jre-hotspot
