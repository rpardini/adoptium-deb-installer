export JAVA_HOME=/usr/lib/jvm/adoptopenjdk-9-jre-hotspot
