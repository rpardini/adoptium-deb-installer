export JAVA_HOME=/usr/lib/jvm/adoptium-8-jre-hotspot
