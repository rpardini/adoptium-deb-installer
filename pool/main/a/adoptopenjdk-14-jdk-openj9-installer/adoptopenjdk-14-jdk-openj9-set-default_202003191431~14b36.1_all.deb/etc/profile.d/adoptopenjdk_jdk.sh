export JAVA_HOME=/usr/lib/jvm/adoptopenjdk-14-jdk-openj9
