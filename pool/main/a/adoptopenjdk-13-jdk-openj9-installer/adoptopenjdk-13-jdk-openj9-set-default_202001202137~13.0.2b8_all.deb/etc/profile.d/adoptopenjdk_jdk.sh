export JAVA_HOME=/usr/lib/jvm/adoptopenjdk-13-jdk-openj9
