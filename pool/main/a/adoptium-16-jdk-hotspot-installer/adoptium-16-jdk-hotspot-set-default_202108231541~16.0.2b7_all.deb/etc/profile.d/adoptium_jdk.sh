export JAVA_HOME=/usr/lib/jvm/adoptium-16-jdk-hotspot
