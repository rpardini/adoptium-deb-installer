export JAVA_HOME=/usr/lib/jvm/adoptopenjdk-15-jdk-openj9
