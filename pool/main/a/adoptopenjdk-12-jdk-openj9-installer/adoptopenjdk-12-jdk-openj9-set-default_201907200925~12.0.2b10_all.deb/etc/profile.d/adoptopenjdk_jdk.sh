export JAVA_HOME=/usr/lib/jvm/adoptopenjdk-12-jdk-openj9
