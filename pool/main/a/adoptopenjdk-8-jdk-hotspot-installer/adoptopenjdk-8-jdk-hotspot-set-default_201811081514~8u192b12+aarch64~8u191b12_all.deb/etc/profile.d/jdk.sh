export JAVA_HOME=/usr/lib/jvm/adoptopenjdk-8-jdk-hotspot
