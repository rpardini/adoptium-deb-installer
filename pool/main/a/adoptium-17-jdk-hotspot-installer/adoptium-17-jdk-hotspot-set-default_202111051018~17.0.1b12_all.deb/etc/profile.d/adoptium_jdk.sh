export JAVA_HOME=/usr/lib/jvm/adoptium-17-jdk-hotspot
