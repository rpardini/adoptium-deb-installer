export JAVA_HOME=/usr/lib/jvm/adoptium-18-jre-hotspot
