export JAVA_HOME=/usr/lib/jvm/adoptium-21-jre-hotspot
