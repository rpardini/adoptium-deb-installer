export JAVA_HOME=/usr/lib/jvm/adoptium-19-jdk-hotspot
