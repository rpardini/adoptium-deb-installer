export JAVA_HOME=/usr/lib/jvm/adoptopenjdk-10-jdk-hotspot
