export JAVA_HOME=/usr/lib/jvm/adoptium-11-jre-hotspot
